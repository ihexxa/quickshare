package downloadmgr

type DownloadMgr struct{}

func NewDownloadMgr() *DownloadMgr {
	return &DownloadMgr{}
}
