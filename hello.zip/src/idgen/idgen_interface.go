package idgen

type IIDGen interface {
	Gen() uint64
}
